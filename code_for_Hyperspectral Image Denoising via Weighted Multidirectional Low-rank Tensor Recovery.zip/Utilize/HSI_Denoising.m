function [E_Img]= HSI_Denoising( N_Img, Par )
E_Img       =  N_Img;                                       % Estimated Image
[H, W, B]   =  size(E_Img);  
N           =  H * W;
% % TotalPatNum =  (H-Par.patsize+1)*(W-Par.patsize+1);         % Total Patch Number in the image
% % Average     =  mean(N_Img,3);                      % Calculate the average band for fast spatial non-local searching
% % % PreCompute all the patch index in the searching window
% % Par         =  NeighborIndex(Average, Par);   
 
for iter = 1 : Par.iter 
%% First step: spectral dimension reduction 
%    k_subspace =  Par.k_subspace + 1;
   Y          =  reshape(E_Img, N, B)';

   [w, Rw]    = estNoise(Y,'additive','off');
   Rw_ori     = Rw;
   Y          = sqrt(inv(Rw_ori))*Y;
   
   [w, Rw]    = estNoise(Y,'additive','off');
   [k, E]     = hysime(Y,w,Rw,'on');
   k_subspace = Par.k_subspace;

   E         =  E(:,1:k_subspace);

   S_Img     =  reshape((E'*Y)', H, W, k_subspace);
%% non-local patch grouping and noise estimation
    [Spa_Img, Spa_Wei]   =  WS_Denoising(S_Img, Par);
%% 
    Z = reshape(Spa_Img./Spa_Wei, N, k_subspace);
    Spa_Img = reshape(Spa_Img, N, k_subspace);
    Spa_Wei = reshape(Spa_Wei, N, k_subspace);
%% Update SubProblem
    k = 1;
    while k <= Par.Innerloop_X
        % update S 
%         W1 = 1./(abs(Y-E*Z')+eps);
%         S = prox_l1((Y-E*Z'),W1*Par.alpha);
        S = sign(Y-E*Z').*max(0,abs(Y-E*Z')-(Par.alpha));
        % update Z
        Z = (Par.lam*Spa_Img + (E'*(Y-S))') ./ (Par.lam*Spa_Wei + 1);
        % update E
        E_est   = (Y-S)*Z;
        [U,~,V] = svd(E_est,'econ');
        E = U*V';    
        k = k + 1;    
    end
    E_Img = E*Z';
    E_Img = sqrt(Rw_ori)*E_Img;
    E_Img = reshape(E_Img', H, W, B);
end
end
