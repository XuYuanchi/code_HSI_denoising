%% HSI Denoising Simulated Experiment
clear;
addpath ./Data
addpath ./Quality_Assess
addpath ./Utilize
%% Load simulated noise HSI data
% you can run Demo_Generate_Simulated_Data to generate more data, 
% but the denoising result may have deviation because of randomness 
load Noisy_Pavia_CASE1.mat; % subspace = 3
% load Noisy_WDC_CASE2.mat; % subspace = 5 for case 1 and 2, 4 for the rest
subspace = 3;
[H,W,B] = size(Noisy_Img);

X = Img;
Y = Noisy_Img;
clear Img Noisy_Img;

[PSNR(:,1), SSIM(:,1), ERGAS(1,1), SAM(1,1)] = MSIQA(X*255, Y*255);
fprintf( 'Noisy Image: nSig = %2.2f, PSNR = %2.2f, SSIM = %2.4f, ERGAS = %2.4f,SAM = %2.4f\n', sigma, mean(PSNR(:,1)),mean(SSIM(:,1)),ERGAS(1,1),SAM(1,1));
%% Subspace NonLocal Low Rank and Sparse Factorization
% t1=clock;
Par = ParSet(sigma, subspace)
[E_Img] = HSI_Denoising(Y, Par);

E_Img(E_Img>1)=1;
E_Img(E_Img<0)=0;
% % t2=clock;
% time = etime(t2,t1);
%% Show results
[PSNR(:,2), SSIM(:,2), ERGAS(1,2), SAM(1,2)] = MSIQA(X*255, E_Img*255);
fprintf( 'Denoised Image: nSig = %2.2f, PSNR = %2.4f, SSIM = %2.4f, ERGAS = %2.4f,SAM = %2.4f\n', sigma, mean(PSNR(:,2)),mean(SSIM(:,2)),ERGAS(1,2),SAM(1,2));
% save WDC_Case1_SNLRSF SNLRSF_Ys mpsnr psnr mssim ssim ergas msa time